module acceptanceb

go 1.27.1

require (
	github.com/skosovsky/toolsy v0.0.0
	github.com/skosovsky/toolsy/toolkits/timetool v0.0.0
)

require (
	github.com/google/jsonschema-go v0.4.3 // indirect
	github.com/santhosh-tekuri/jsonschema/v6 v6.0.3 // indirect
	golang.org/x/text v0.42.0 // indirect
)

replace github.com/skosovsky/toolsy => "/Users/skosovsky/Library/Mobile Documents/com~apple~CloudDocs/Загрузки/Projects/ai/toolsy"

replace github.com/skosovsky/toolsy/toolkits/timetool => "/Users/skosovsky/Library/Mobile Documents/com~apple~CloudDocs/Загрузки/Projects/ai/toolsy/toolkits/timetool"

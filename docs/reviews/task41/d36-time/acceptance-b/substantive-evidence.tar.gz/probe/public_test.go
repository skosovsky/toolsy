package acceptanceb

import (
 "context"
 "encoding/json"
 "errors"
 "fmt"
 "strings"
 "testing"
 "time"
 _ "time/tzdata"

 "github.com/skosovsky/toolsy"
 "github.com/skosovsky/toolsy/toolkits/timetool"
)

func execute(t *testing.T, tool toolsy.Tool, env *toolsy.RunEnv, input string) (map[string]any,error) {
 t.Helper(); var result map[string]any
 err:=tool.Execute(t.Context(),env,toolsy.ToolInput{ArgsJSON:[]byte(input)},func(c toolsy.Chunk)error{return json.Unmarshal(c.Data,&result)})
 return result,err
}

func TestIndependentExactCalendarContracts(t *testing.T) {
 // Arrange: host zone is deliberately different from each input's offset.
 ny,err:=time.LoadLocation("America/New_York");if err!=nil{t.Fatal(err)}
 tools,err:=timetool.AsTools(timetool.WithLocation(ny));if err!=nil{t.Fatal(err)}
 for _,f:=range []struct{base,want string;days,hours int;elapsed time.Duration}{
 {"2026-03-07T12:00:00-05:00","2026-03-08T12:00:00-04:00",1,0,23*time.Hour},
 {"2026-03-07T12:00:00-05:00","2026-03-08T13:00:00-04:00",0,24,24*time.Hour},
 {"2026-10-31T12:00:00-04:00","2026-11-01T12:00:00-05:00",1,0,25*time.Hour},
 {"2026-10-31T12:00:00-04:00","2026-11-01T11:00:00-05:00",0,24,24*time.Hour},
 {"2026-03-08T12:00:00-04:00","2026-03-07T12:00:00-05:00",-1,0,-23*time.Hour},
 {"2026-03-08T12:00:00-04:00","2026-03-07T11:00:00-05:00",0,-24,-24*time.Hour},
 {"2026-11-01T12:00:00-05:00","2026-10-31T12:00:00-04:00",-1,0,-25*time.Hour},
 {"2026-11-01T12:00:00-05:00","2026-10-31T13:00:00-04:00",0,-24,-24*time.Hour},
 {"2026-03-07T01:30:00-05:00","2026-03-08T04:30:00-04:00",1,2,26*time.Hour},
 {"2026-03-09T01:30:00-04:00","2026-03-07T23:30:00-05:00",-1,-2,-25*time.Hour},
 {"2026-03-07T22:45:00.987654321+05:45","2026-03-07T12:00:00.987654321-05:00",0,0,0},
 } {
 // Act.
 input:=fmt.Sprintf(`{"base_date":%q,"add_days":%d,"add_hours":%d}`,f.base,f.days,f.hours)
 r,e:=execute(t,tools[1],toolsy.NewRunEnv(nil),input)
 // Assert exact string, instant elapsed delta, and weekday.
 if e!=nil{t.Fatal(e)}; if r["result"]!=f.want{t.Fatalf("%s got %v want %s",input,r,f.want)}
 base,_:=time.Parse(time.RFC3339Nano,f.base);got,_:=time.Parse(time.RFC3339Nano,f.want)
 if got.Sub(base)!=f.elapsed||r["weekday"]!=got.In(ny).Weekday().String(){t.Fatalf("delta/weekday %v",r)}
 }
}

func TestIndependentLocationPolicy(t *testing.T) {
 // Arrange: dynamic zones must override static on each of both tools.
 calls:=0;tools,err:=timetool.AsTools(timetool.WithLocation(time.UTC),timetool.WithLocationProvider(func(context.Context,*toolsy.RunEnv)(*time.Location,error){calls++;return time.FixedZone("dynamic",calls*15*60),nil}));if err!=nil{t.Fatal(err)}
 for _,i:=range []int{1,0,1,0,1,0}{input:=`{}`;field:="local";if i==1{input=`{"base_date":"2026-01-01T00:00:00Z","add_days":0,"add_hours":0}`;field="result"}
 // Act.
 r,e:=execute(t,tools[i],toolsy.NewRunEnv(nil),input)
 // Assert.
 if e!=nil{t.Fatal(e)};stamp,e:=time.Parse(time.RFC3339Nano,r[field].(string));if e!=nil{t.Fatal(e)};_,offset:=stamp.Zone();if offset!=calls*15*60{t.Fatalf("offset %d call %d",offset,calls)}
 }
 for _,kind:=range []string{"nil","error"}{sentinel:=errors.New("external failure");tools,_:=timetool.AsTools(timetool.WithLocation(time.UTC),timetool.WithLocationProvider(func(context.Context,*toolsy.RunEnv)(*time.Location,error){if kind=="error"{return nil,sentinel};return nil,nil}))
 for i,input:=range []string{`{}`,`{"base_date":"2026-01-01T00:00:00Z","add_days":0,"add_hours":0}`} {r,e:=execute(t,tools[i],toolsy.NewRunEnv(nil),input);if e==nil||r!=nil{t.Fatalf("fallback %s %v %v",kind,r,e)};if kind=="error"&&!errors.Is(e,sentinel){t.Fatal(e)};if kind=="nil"&&!strings.Contains(e.Error(),"location provider returned nil"){t.Fatal(e)}} }
 // A nil callback disables override and preserves static +05:45 for both tools.
 tools,_=timetool.AsTools(timetool.WithLocation(time.FixedZone("static",345*60)),timetool.WithLocationProvider(nil))
 for i,input:=range []string{`{}`,`{"base_date":"2026-01-01T00:00:00Z","add_days":0,"add_hours":0}`} {r,e:=execute(t,tools[i],toolsy.NewRunEnv(nil),input);if e!=nil{t.Fatal(e)};field:="local";if i==1{field="result"};if !strings.HasSuffix(r[field].(string),"+05:45"){t.Fatal(r)}}
}

type store struct{loads,saves int;raw []byte}
func(s *store)Load(context.Context,string)([]byte,error){s.loads++;return s.raw,nil}
func(s *store)Save(_ context.Context,_ string,b []byte)error{s.saves++;s.raw=append([]byte(nil),b...);return nil}
func TestIndependentStateBoundary(t *testing.T){
 // Arrange: persisted and session values share a key but must remain independent.
 reg,e:=toolsy.NewRegistryBuilder().Build();if e!=nil{t.Fatal(e)};session,e:=toolsy.NewSession(reg);if e!=nil{t.Fatal(e)}
 persisted:=&store{raw:[]byte("EXTERNAL-ONLY")};env:=toolsy.NewRunEnv(session,toolsy.WithStateStore(persisted));if e=toolsy.SetSessionState(session,"host.timezone","IN-MEMORY");e!=nil{t.Fatal(e)}
 // Act: snapshots and default time tools may not touch external storage.
 snap,e:=session.ExportSnapshot();if e!=nil{t.Fatal(e)};wire,e:=json.Marshal(snap);if e!=nil{t.Fatal(e)}
 tools,e:=timetool.AsTools(timetool.WithLocation(time.UTC));if e!=nil{t.Fatal(e)};for i,input:=range []string{`{}`,`{"base_date":"2026-01-01T00:00:00Z","add_days":0,"add_hours":0}`} {if _,e=execute(t,tools[i],env,input);e!=nil{t.Fatal(e)}}
 // Assert: explicit host Load/Save is separate; snapshot contains only session value.
 if persisted.loads!=0||persisted.saves!=0||strings.Contains(string(wire),"EXTERNAL-ONLY")||!strings.Contains(string(wire),"IN-MEMORY"){t.Fatalf("boundary %s %+v",wire,persisted)}
 if e=env.StateStore.Save(t.Context(),"host.timezone",[]byte("UTC"));e!=nil{t.Fatal(e)};if b,e:=env.StateStore.Load(t.Context(),"host.timezone");e!=nil||string(b)!="UTC"{t.Fatal(e)}
 value,ok:=toolsy.GetSessionState[string](session,"host.timezone");if !ok||value!="IN-MEMORY"{t.Fatalf("session mutated %s",value)}
}

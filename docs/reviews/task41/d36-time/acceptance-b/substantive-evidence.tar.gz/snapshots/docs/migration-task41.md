# Task 41 API migration

## HTTP redirects (R01)

Agents, OpenAPI and GraphQL no longer transparently reroute RPCs. Configure the
final endpoint in `agents.NewClient`, `openapi.Options.BaseURL` / source servers,
or `graphql.Introspect`. The specification URL itself must remain within its
original origin on GET redirects.

Their shared `httptool.CheckRedirectRemote` accepts only requests that started
as GET/HEAD and remain within the original scheme, hostname and effective port.
Different ports and subdomains are different origins; HTTPS downgrade and HTTP
upgrade both cross that boundary. Same-origin GET/HEAD redirects retain headers.
The default web scraper and remote document reader use the same helper, so
their GET redirects must also remain within the original origin; supply the
final URL explicitly. Their initial URL validation remains correctable; a
refused redirect does not. MCP HTTP also uses this helper: POST RPCs and DELETE
session termination do not redirect, GET/HEAD stay in the original origin, and
method-changing RPC redirects use the same typed refusal contract.

`httptool.CheckRedirectAllowed` still permits whitelisted GET/HEAD redirects,
removing Authorization, Cookie and Proxy-Authorization on origin changes.
Both helpers now refuse every redirect for an initial POST/PUT/PATCH/DELETE or
other method, even if HTTP would rewrite it to GET. GraphQL queries and
introspection use POST, so neither redirects. HTTP toolkit POST also refuses
redirects; configure its final URL in the authorized call.

A refused redirect is inspectable with `errors.As` as `*httptool.RedirectError`.
The outer `ToolError` uses nonretryable `CodeRemoteExecution`, including URL,
IP, whitelist and blacklist refusals during redirect validation. An underlying
validation cause remains inspectable, but the outer classification does not
authorize correction/retry.
The first request was already dispatched and may have produced effects; use the
host's reconciliation contract before deciding on a new request. Agent create
continues to wrap the error in its unknown-outcome envelope.

`NewSafeHTTPClient` accepts an explicit host redirect callback; hosts supplying
their own callback own its method/origin/header/body semantics. Nil disables
redirects. Consumer custom clients continue to merge timeout only; they cannot
override these adapter policies.

## Host allow/deny patterns (R02 / D17)

`MatchHost`, `HostBlocked`, `HostMatchesAllowedDomains`, `SafeDialOptions` and
toolkit domain options now share one syntax:

| Entries | Matches |
|---|---|
| `example.com` | Exact apex only |
| `.example.com` | Descendants only, including nested subdomains |
| `example.com` and `.example.com` | Apex plus all descendants |

Previously bare entries also matched descendants. Update any allowlist that
intended that behavior to include the leading-dot entry explicitly. **Update
blacklists too:** replacing an old `"evil.com"` entry with
`"evil.com", ".evil.com"` preserves the previous apex-plus-descendants denial.
This applies to `web.WithBlockedDomains` and to shared HTTP library consumers.
Leaving only the bare entry intentionally denies the exact apex alone.

Case and surrounding whitespace are ignored. A terminal DNS root dot is
normalized on both configured patterns and request hosts, so `EXAMPLE.com.` and
`example.com` have identical host policy. A leading-dot pattern does not match
the apex or a name such as `evil-example.com`. IP checks still apply at dialing.

Every matching deny entry takes precedence, including broad allow plus narrow
deny and identical suffix policies. This replaces the precomputed exact
`conflictDeny` map. Denials happen before DNS lookup or dialing. A configured
nonempty allowlist that normalizes to no usable entries remains deny-all; it
does not silently switch to permissive blacklist mode.

## Exact input numbers and structure (R03)

Validated typed, dynamic and proxy inputs now use the same lossless JSON parser
and exact-number JSON Schema compiler. Dynamic `ValidateArgs`/`Handler` maps and
numbers inside typed `any`/map/interface fields contain `json.Number`. Replace
`value.(float64)` assertions with `value.(json.Number)` and explicit `Int64` or
`Float64` conversion, handling errors. Prefer declared `int64` fields for IDs;
explicit Go float fields still choose floating-point semantics. Values already
rounded by the host before constructing a schema/input cannot be recovered.
Use `json.Number` or integral Go values for exact numeric schema constraints.

Minimum, maximum and enum validation preserves distinctions beyond 2^53,
including max int64; prepared snapshots and cache identities retain those digits.
Schema normalization preserves property names such as `id` and literal
const/enum/default objects. Internal input compilation uses the same default
JSON Schema draft 2020-12 engine as proxy/output validation; explicit supported
dialects are honored and external schema loading stays disabled.

All validated input paths reject duplicate object keys recursively (including
escaped spellings of the same key), trailing JSON documents and malformed JSON.
Root depth is zero; values deeper than 128 or documents above 100,000 value
nodes are rejected before dispatch. These are structure limits, not byte budgets;
hosts still bound input bytes and string lengths. This intentionally replaces
typed/dynamic last-key-wins behavior. Declared custom `UnmarshalJSON` methods
remain host-owned after the shared structure/schema check; they can choose their
own Go representation. Typed field-name matching follows encoding/json rules.

## Post-handler validation and claimed operations (R04 / D12)

Typed `ResultValidator`, `EffectValidator` and `Postcondition` failures now have
an outer nonretryable `CodeInternal` error with no fixable arguments. Use
`errors.As` for `*ResultContractError`: its `Kind` identifies the failing phase
(`result_validator`, `effect_validator`, `postcondition`), and `Unwrap` retains
the exact original cause. Even a callback-supplied correctable/retryable ToolError
cannot override the known post-handler classification. Inspect the **outer**
ToolError for routing; finding a validation sentinel deeper in the cause chain
does not authorize argument correction or redispatch. Registry/Session timeout
normalization also preserves this classification when the callback cause is
context.DeadlineExceeded.

Pre-handler argument/schema errors keep their existing correction semantics.
A post-handler rejection emits no result and does not undo external effects.
See the runnable [contract_recovery example](../examples/contract_recovery/main.go).

`OperationOutcomeError` now says “after claim; dispatch may have occurred”. Its
`DispatchInvoked` field records whether this profile invoked its continuation;
false is local diagnostic evidence, not a fenced proof of externally not-started
and not permission to roll back the claim. Cancellation, lease/approval expiry
before invoke and post-handler failures all leave an unfinished claimed attempt
unknown. Reconcile through the bound operation reference; repeated delivery does
not blindly dispatch it. A persisted completed result stays completed if delivery
later fails. Use keyed error literals when constructing OperationOutcomeError.

The public error-chunk formatter preserves nonretryable INTERNAL and emits host
reconciliation guidance for these known failures. WithErrorFormatter leaves them
as hard errors. Batch/iterator/control routing cannot treat a diagnostic timeout,
stream-abort or control sentinel in their cause as permission to suppress the
contract failure or pause the host. errors.Is still exposes the original cause.
Shared web/RAG/SQL host result validators use the same result_validator phase;
this does not claim that a read performed an external write. Formatter callbacks
and output byte-cap policies are separate contracts.

## Release preparation (R05 / D37)

`make release-patch` and `make release-break` now build the host CLI and prepare
committed HEAD in a private clone. Linux and macOS are supported. The source
checkout must have no tracked changes. Untracked and ignored files remain local;
they never become candidate inputs. The source branch, index, files and refs are
preserved on success, failure and cancellation. Effective Git identity plus commit.gpgsign, gpg.format and user.signingkey
are copied into the private clone; hooks are disabled there. Other host Git
settings remain inherited from the host, so repository-specific signing programs
may need host configuration. Signing failure aborts before publication.

The inventory comes from all committed `go.mod` paths. An optional legacy module
list must equal that inventory. All module paths must follow the root module plus
the relative directory. Internal dependencies must form a DAG; cycles and missing
owned modules fail explicitly. Manifest edits use `go mod edit`, align owned
requirements and remove owned development replaces. External local replaces and
nonregular manifests/checksum files are rejected. Only expected `go.mod`/`go.sum`
files are staged. Before checkout, a private index and cached attribute check
reject attributes that transform checkout/archive bytes: filter, working-tree-encoding,
export-ignore, export-subst, ident, crlf, text and eol (absent or explicitly unset
attributes are allowed). Ordinary diff/merge/linguist metadata is supported. Host
global attributes are included in this check. Checkout uses LF and real symlinks.
Bootstrap applies the same attribute preflight before building its Git archive.

For each module, in dependency order, preparation tidies its release manifest,
creates the Go module ZIP with `x/mod/zip` (including inherited root LICENSE),
downloads that ZIP through an invocation-owned file proxy, and compiles its packages
and tests with `GOWORK=off` and `-mod=readonly`. Peer ZIP checksums are final before
preparing dependents. Each module has a ten-minute verification deadline. The CLI
then runs `make lint test` in the private checkout and the existing break preflight,
when present, with a thirty-minute deadline. Tracked changes from checks abort the
release. This verification checks the exact artifact graph; it does not execute
all dependency tests from their downloaded ZIPs.

The private module cache and GOPATH (including checksum-database state) are removed
on exit. Existing downloaded archives provide a read-only fallback before the
configured GOPROXY. Existing external GONOSUMDB policy is retained. If GONOPROXY
matches any owned module, verification sets that bypass to `none` and uses only
cached archives or direct VCS for external dependencies, preventing private module
names from reaching a public proxy. This case requires cached dependencies or
working VCS access; a proxy-only installation may fail explicitly. Existing Go
build/lint caches may still be reused.

To verify without publication, run
`bash scripts/release.sh -prepare-only patch`. The host wrapper archives committed runner code into a private bootstrap directory
and builds with
`GOWORK=off`, `-mod=readonly` and `-buildvcs=false`. SIGINT/SIGTERM cancel preparation
and terminate CLI command process groups before private-directory cleanup. The
bootstrap build has its own job process group; cancellation sends TERM, waits at
most two seconds, then sends KILL to that group and removes its directory.
Publication confirmation owns its input reader; Close must unblock Read.

The wrapper clears Git repository-selector environment variables and rejects
counted/serialized inline Git configuration before bootstrap; configure bootstrap
authentication in normal Git config or SSH facilities. The native CLI supports
counted authentication/identity configuration, strips counted repository, hook,
fsmonitor and checkout overrides, and rejects GIT_CONFIG_PARAMETERS. These
overrides cannot redirect its private index/worktree or change verified bytes.

Publication uses explicit root/submodule tag refspecs from this invocation, with
--atomic and --no-follow-tags; mirror configuration is disabled for that command.
Unrelated local tags never enter the train. Exactly one push destination is
required; fetch and push destinations may differ. Local and push-remote collisions
are checked before manifest preparation and again after confirmation. Existing
refs are never deleted or forced. A server without atomic push support or a
rejected tag fails the whole train; there is no sequential fallback.

Preflight cannot lock remote refs. Git arbitrates concurrent conflicting updates
at atomic push; an identical concurrent tag may be reported up-to-date. A transport
failure after the server accepted a push leaves publication outcome uncertain:
inspect the remote before retrying. Local cleanup does not roll back remote tags.
All release regressions use disposable local bare remotes; no production
publication is used for verification.

## HTTP pool ownership and explicit settings (R07 / D18 / D19)

Replace `WithHTTPClient` / `Options.HTTPClient` and `MergeHTTPClient` with explicit
`httptool.ClientSettings{Timeout: ..., TLSConfig: ...}` through
`WithHTTPSettings` / `Options.HTTPSettings`. MCP uses
`WithStreamableHTTPSettings` instead of `WithStreamableHTTPClient`; invalid
settings fail Start, and transport Close releases its owned idle pool. Custom Do, transport, proxy, roots or
tracing clients are no longer silently accepted. Roots/client certificates belong
in TLSConfig and are applied to the pinned safe transport; custom Do/proxy/dial
ports are unsupported. TLSConfig is cloned. Referenced root pools, certificate
slices/private keys and callbacks remain immutable host-owned state.

`agents.NewClient` now returns `(*Client, error)`. Each client owns one reusable
pool for its REST/SSE lifetime. At disposal stop initiating calls, then invoke
`CloseIdleConnections`. `httptool.AsToolsWithCleanup`, `web.AsToolsWithCleanup`,
`document.AsToolWithCleanup`, `openapi.ParseURLWithCleanup` and
`graphql.IntrospectWithCleanup` return `(tools, closeIdle, error)` (document
returns a single tool). The closer releases only owned idle resources and leaves
active calls unaffected; it is not terminal Close. Compatibility factories keep
the same simpler return shape and automatic bounded idle expiry. One-shot
`web.ScrapePage` disposes its own pool on return. No caller HTTP client is accepted
or closed. Pools retain at most 32 idle connections overall, two per host, for
at most 90 seconds. These are idle bounds, not request/concurrency limits.

Timeout must be nonnegative. Zero leaves the request under its context deadline;
HTTP probe tools preserve their 30-second default. Agent SSE has a separate
logical StreamPolicy deadline; a positive HTTP timeout also limits each response
body lifetime. TLS handshake and dial have finite transport deadlines.

DNS lookup and sequential attempts share a total dial deadline. Validate every
resolved IP before the first attempt; then dial only those addresses, without
re-resolving. Allocate each attempt a share of remaining time and stop on caller
cancellation. Host deny precedence, DNS pinning and redirect credential/effect
policies remain. No environment proxy bypass is introduced.

Stream byte caps retain stop-after-budget semantics. An exactly exhausted cap
without EOF on that Read produces a limit error on the next nonempty Read; the
reader cannot prove exact EOF without probing past the cap. Empty reads consume
nothing, and cancellation takes precedence. No speculative EOF read is made.

## Concurrent session rebinding (R08)

Session registry and binding now occupy one immutable configuration snapshot.
Rebind computes the target outside configuration locks, then atomically validates
against the current binding and publishes with CAS. Incompatible targets leave
configuration and state unchanged. Public Binding returns a detached clone.
Execute and RunCall capture one registry per call; manifest/completion policy and
dispatch stay on that registry even if a host callback rebinds the session. Later
calls see the replacement. Existing calls are not canceled or migrated.

ExportSnapshot captures one binding and copies state-map slots, then invokes
codecs/MarshalJSON without holding state/configuration locks. ExportCheckpoint
uses that snapshot's binding for its outer metadata, so the two cannot diverge.
Map replacement on ImportSnapshot remains atomic; decode callbacks run before
replacement without locks. Snapshot export does not deep-copy host values; their
referenced data must remain immutable while encoding, or host-synchronized by the
codec. Registry configuration must remain stable after setup; codec registrations
are finalized automatically by NewSession as described below.
The exported state map is a captured set of slots, not a transaction across
external mutable objects or concurrent handler effects.

## State codec lifecycle and checkpoint scope (R09, D07, D08)

Register every state slot before constructing the first session. `NewSession`
validates the run policy and registry binding, then freezes the supplied shared
`StateCodecRegistry` before computing its state schema digest. Registration and
freeze linearize under the builder lock: a concurrent registration either becomes
part of that fixed schema or returns `ErrStateCodecRegistryFrozen`. All registrar
paths enforce this rule, including required slots and prototype codecs. Explicit
`Freeze()` is nil-safe and idempotent; schema changes require a new builder.
Invalid policy/registry constructor validation leaves an unfrozen builder mutable.
`NewSessionFromCheckpoint` finalizes the builder before checkpoint compatibility
and hydration checks, even if those later checks fail.

Required slots must be present when exporting and importing. Missing or untyped
nil required values fail export. A registered non-nullable slot encoding JSON
null also fails export; nullable slots may roundtrip typed nil through their codec.
The library fixes slot metadata, not arbitrary host callback behavior. Custom
codecs must roundtrip their values, use stable schema IDs, and support concurrent
calls; referenced callback state remains host-owned.

`SessionCheckpoint` is a state-plus-binding checkpoint. It does not save RunPolicy,
maxCalls, consumed call-attempt count, dependencies, StateStore contents, external effects,
or a workflow continuation. Restoring supplies current host authority/configuration
and starts fresh in-memory counters. Hosts must enforce durable budgets and restore
workflow position themselves before dispatch.

Set/Get synchronize map slots and preserve BYOT references. Pointers, maps, and
slices remain aliased; the host must synchronize mutation or keep values immutable
during access/encoding. Codec/MarshalJSON callbacks run outside state/configuration
locks and may reenter the session. Import replaces the map only after successful
hydration; callback writes and external side effects are not rolled back when
hydration fails. This is not a deep-copy or transactional callback contract.

## RunPolicy snapshots and call admission (R10, D06)

`WithRunPolicy` copies AllowedTools and CatalogRequiredTools at capture and at each
materialization. NewSession owns independent execution/options snapshots. Mutating
original slices after option creation or construction cannot change validation or
admission; reused options are independent. Do not mutate a slice concurrently
with the initial WithRunPolicy capture itself. Dynamic policy updates are not
provided; construct a new session with current authority.

Clear break: replace `RequiredTools` with `CatalogRequiredTools` for presence in
the visible session catalog. Missing names fail construction with
TOOLS_CONTRACT_MISSING before codec freeze. It never restricts calls. To preserve
the old RequiredTools-only whitelist behavior, migrate that list to AllowedTools.
Catalog requirements may be outside AllowedTools and ForcedTool. ForcedTool still
must be in AllowedTools when the latter is nonempty. Registry/View capability
policy remains an independent boundary.

Replace `WithMaxSteps`, `Track().MaxSteps()`, `Track().ExecutionCount()` with
`WithMaxCalls`, `Track().MaxCalls()`, `Track().CallAttempts()`. Error APIs are now
ErrMaxCallsExceeded / CodeMaxCallsExceeded / NewMaxCallsExceededError, and the
serialized code is `MAX_CALLS_EXCEEDED` instead of `MAX_STEPS_EXCEEDED`. Update host
wire-code switches/readers; the obsolete code no longer maps to the budget
sentinel/classification in the new reader.
Zero remains unlimited; a negative limit now fails construction.

Accounting order is unchanged: nil registry and RunPolicy rejection consume no
attempt; otherwise atomically increment CallAttempts and reject attempts above the
limit. Budget-rejected attempts remain counted. Environment binding, registry
capability/policy, argument validation, cancellation, tool failure and result replay
all occur after admission and consume that attempt. Internal middleware retries
consume one admission; each nested Session.Execute and each fresh RunCall consumes
its own admission. At most maxCalls attempts can pass this gate under concurrency.
This counter does not measure handler effects or successful results and does not
model LLM/agent iterations. Checkpoints do not persist it; the host enforces durable
budgets and supplies current policy/limits when restoring.

## Empty delivery and result algebra (R11, D16)

Empty results now always build their declared success envelope. Audience, delivery
class and metadata survive direct execution, registry delivery, RunCall and result
replay. Typed Value, effects and controls remain present; Data and MIME are absent.
No fake JSON zero value is created.

| Declaration | Typed/wire payload | Effects | Controls |
|---|---|---|---|
| Ordinary Value | Value plus JSON encoding | Allowed | Allowed |
| Nonempty Raw | Value retained; Raw overrides wire only | Allowed | Allowed |
| Empty | Value retained; wire absent | Allowed | Allowed |
| Noop | Value retained; wire absent | Forbidden | Allowed |

Empty and Noop are mutually exclusive. Either with nonempty Raw is invalid; Noop
with Effects is invalid. RawMimeType without nonempty Raw is invalid. Raw defaults
to application/octet-stream; an empty Raw slice alone is not a wire override.
Use Empty for a result without a payload. Delivery class defaults to structured
and audience to model when unspecified, including results without wire bytes.

Clear break: NewNoopToolResult no longer serializes a zero TResult
into wire bytes; its typed Value remains available. DecodeOutcomeAs returns
an available typed Value; when absent, neither status has wire bytes to decode.
ResultValidator is skipped for Empty/Noop; EffectValidator and
Postcondition still run for valid declarations. Generic result chunks and replay
validation reject contradictory flag/wire/effect combinations too. An error
result cannot declare Empty/Noop success status. Invalid
result algebra is an INTERNAL ResultContractError with Kind result_algebra and
cause; the handler may already have caused effects, so this never permits blind
redispatch. Noop is a host declaration, not proof of absence of external effects.

Existing persisted results with Empty/Noop plus old wire bytes are incompatible.
Typed values without wire bytes remain supported, including MCP protocol DTOs.
Version host cache partitions/codecs or migrate records deliberately. Do not
evict durable completed-operation/idempotency records to force a new dispatch;
use trusted host migration/reconciliation while retaining the operation boundary.

Generated nested json.RawMessage output now maps to an unrestricted JSON schema
(true), accepting object/array/string/number/boolean/null instead of object only.
Arguments retain their documented object default. Explicit host SchemaRegistry
mappings override defaults at both boundaries; defaults are applied to a local
schema-map copy and never mutate the shared registry. WithOutputSchema overrides
automatic output inference. Top-level json.RawMessage/JSON marshaler/WireJSONResult
wire shapes remain uninferred: set WithOutputSchema when shape constraints matter.
Arbitrary custom nested marshaler shapes also need an explicit schema; reflection
cannot infer them from storage types. Only JSON wire bytes are schema-validated;
typed Value stays BYOT and may intentionally differ from Raw representation.

Reflective snapshot cloning copies supported exported struct fields and
pointer/map/slice/array values, preserving cycles and repeated references within
one cloned value. Opaque private fields, functions/channels and pointer-map-key
identity remain host-owned. Overlapping subslices with different lengths and
separately cloned components do not promise a shared alias graph, backing-array
capacity or universal identity preservation. Delivery is not a universal deep
copy of every host object: keep borrowed typed values/opaque data immutable while
they are consumed, and use a complete trusted ResultCodec for persistence. No
JSON roundtrip is introduced to simulate cloning arbitrary BYOT types.

## R12 / D13 / D15 — explicit reuse and replay source

Clear break: NewResultCache takes `(store, eligibility, partition, codec, maxBytes)`.
CacheEligibility is `func(context.Context, PreparedCall) (bool, error)`; it runs
on every currently authorized attempt, including hits. False invokes the handler
without partition/storage/codec work. Idempotent and ReadOnly are classifications,
not freshness proofs. Do not migrate by blindly returning true for every tool.
Approve reuse only for a domain result whose freshness, principal/scope and relevant
input/dependency revisions are bound to the trusted partition/store expiry policy.
Concurrent misses may dispatch twice; use OperationProfile for durable effect
identity/recovery rather than the cache.

Business-error terminal chunks keep their delivery and RunCall classification;
they are never persisted. Missing/multiple terminals, limits and host cache
infrastructure errors now fail INTERNAL, nonretryable and not input-correctable.
Causes remain available to host diagnostics. After dispatch such failure does not
prove that an effect was rolled back or authorize automatic redispatch.

Clear break: remove CacheReplayMetadata / `toolsy.cache_replay` boolean checks.
ReplaySourceMetadata (`toolsy.replay_source`) stores a string:
ReplaySourceCache (`result_cache`) for reusable data, or ReplaySourceOperation
(`completed_operation`) for an already-completed durable logical operation.
Reducers skip effect application for either source. Current CallID/ToolName remain
rebound on delivery. Policy configuration cannot set this reserved key; repeated
metadata overlays retain it and keep private replay audiences private.
A trusted profile stamps the actual source, overwriting any stored source. The
marker is provenance, not a permission grant or authenticity proof for arbitrary
custom-tool output.

Old encoded successful records may retain their old metadata, but current replay
adds the new authoritative source. Host reducers must use the new key; do not
interpret absence of the old key as a fresh dispatch. If custom codecs reject the
new metadata or rely on a boolean schema, deliberately migrate those records.
Never evict durable completed-operation records to force redispatch. Cache entries
may be invalidated under the host's ordinary reuse policy; journal outcomes require
fenced reconciliation. Codec and opaque host value ownership remain unchanged.


## R13 / D20 / D21 / D22 — MCP correlation and bounded discovery

Clear break: WithLogger becomes WithStdioLogger. Replace the old combined
WithStdioMaxStreamBytes / WithStreamableHTTPMaxStreamBytes options with
WithStdioLimits / WithStreamableHTTPLimits using TransportLimits. Frame/queue/
in-flight/lifetime bounds have separate meanings. Default frames are 1MiB,
retained outgoing bytes 16MiB and in-flight requests 64; lifetime zero is unlimited.
Set MaxLifetimeBytes explicitly if process/per-response total traffic must be
bounded. Set a larger frame cap explicitly for large responses or requests.
Negative/nil transport/client options fail early. FrameByteCapTransport.MaxFrameBytes
replaces the old StreamByteCapTransport.MaxStreamBytes custom facet.

Clear break: Client.ListTools becomes ListToolsPage; it never updates tool routing
authority, even for a single complete page. Use DiscoverTools for a full typed
validated snapshot and transactional publication, or Discover (formerly GetTools)
for generated proxies. Full discovery bounds aggregate raw bytes/items/pages/
cursors before accumulating descriptors/compiling schemas; input and output schemas
must validate before authority publication. Original page cache hints remain in
ToolDiscovery.Pages, with no fabricated aggregate TTL. Update manual HTTP callers
that previously relied on the single-page ListTools side effect. Host authorization
and cache freshness are still separate from remote descriptors/mapper properties.

Locally canceled subscriptions retain bounded ID correlation (64 active/1024
tracked IDs/one minute by default). Capacity reserves eventual retirement space;
new Listen fails at saturation instead of evicting live/retired routes. Late ACKs
and notifications for retained locally canceled IDs do not alter generations or
cancel unrelated subscriptions. Outside the configured time window the strict
unknown-ID policy applies again. Truly unknown/malformed traffic remains a protocol
error. Configure SubscriptionLimits for the trusted deployment's cancellation and
latency envelope; custom transports must not reuse IDs in that window. This is
bounded correlation, not a claim to accept arbitrary infinitely delayed traffic.

See [MCP limits and minimal transport](../mcp/README.md#transport-discovery-and-subscription-limits)
for supported callback, queue, overflow, framing and cancellation guarantees.

R13 publication checks cancellation under the authority lock immediately before
starting the synchronous commit. Once `ReplaceToolHeaderBindings` starts, later
cancellation cannot roll back a successful commit. This trusted facet must replace
atomically (errors retain old bindings), finish in bounded time, and must not
reenter Client methods. Holding the authority lock preserves matching client and
transport snapshots; a reentrant transaction would require a different port
contract. Descriptor mapper callbacks retain their existing reentry behavior.
Transport queue/count refusals expose `TransportLimitError` with
`ErrTransportLimitExceeded`; frame failures preserve `ErrReadLimitExceeded`.

## R14 / D28 — host descendants and failed cleanup outcomes

Unix host execution now launches the runtime directly and uses a separate /bin/sh
anchor with a private hold pipe. It stops owned group descendants before workspace removal
on every completion path, signaling only while the group leader is unreaped. Guest start errors and exit statuses retain Go exec semantics. Escaped groups and
non-Unix process-tree termination are not covered. Cleanup confirmation is bounded;
failed confirmation retains the workspace and exposes CleanupError.ResourceID.

exectool failed execution retains the sandbox-returned RunResult in RunOutcomeError
reachable through errors.As; the cause and error classification remain inspectable.
There is no successful result chunk on failure. A returned zero/partial result is
not automatically complete, and cleanup failure must not trigger a blind retry.

## R15 / D29 — exact Starlark output and focused Docker configuration

Starlark RunResult.Stdout now retains every printed newline on both exit0 and
exit1, including trailing empty lines. Consumers choose presentation trimming.
The internal finalizer trim flag is removed across all sandbox adapters.

Docker WithClient accepts exported Client, the focused adapter lifecycle port;
its mandatory context/reader/capability contract is in the adapter README. The
constructor-validated policy is the only source of output/log-timeout bounds.
Starlark fs.read limit errors intentionally remain guest exit1 with bounded stderr;
stdout/stderr collection overflow remains an infrastructure/output error.

## R16 — HTTP toolkit response encoding

GET/POST JSON body strings now require valid UTF-8 response bytes. Invalid UTF-8
is rejected before bytes-to-string/JSON replacement; no Content-Type charset
inference, transcoding or implicit binary wrapper. Valid UTF-8/status/body shape
is unchanged. Binary hosts use byte-oriented library readers and explicit encoding.

Encoding failure exposes ErrInvalidUTF8Response and ResponseEncodingError with
method/status through CodeInternal ResultContractError. POST response read/wire
limit errors also become result-phase CodeInternal with their original causes;
pre-dispatch request and GET read/wire bounds retain their validation categories.
These failures never emit success or authorize repair/retry of an already dispatched
POST. Caller cancellation keeps its precedence and does not imply effect rollback.


## R17 / D33 — explicit mail body representation

MessageBody now has Representation BodyRepresentation. Zero and BodyPlainText
mean UTF-8 plaintext, retained byte-for-byte, including leading/trailing whitespace,
angle-bracket addresses, placeholders and XML. Set BodyHTML for declared HTML;
it alone converts to Markdown. MIME parsing/charset decoding belongs to host reader
adapters; the toolkit neither guesses nor transcodes. Unsupported declarations and
invalid UTF-8 fail explicitly.

mail_read_message JSON adds representation (`text/plain` or `text/markdown`)
beside body (which retains the existing message metadata prefix). HTML conversion
failure is INTERNAL ResultContractError preserving its cause, with no original HTML
fallback or successful output. Cancellation is observed before/after synchronous
conversion; this is not a hard CPU deadline. Raw body/item/source limits precede
conversion; final JSON budget includes escaped output and representation. Host reader
transport/allocation limits remain required. Send/approval payloads unchanged.


## R18 / D31 — cancellable session scratchpad

Scratchpad uses one context-aware admission gate per instance around complete
Load/modify/Save. Canceled waiters return without waiting for the current store
callback and without invoking storage. Context rechecked after admission and around
load/before save. No per-session lock map or waiter goroutine is created. Calls
through one instance remain serialized across all supplied sessions; no fairness
promise. Use one instance as sole writer for each state key. Do not copy Scratchpad
or synchronously reenter it from store callbacks. Multiple instances/processes need
host coordination; Load/Save is not CAS.

memory_read_all changes `facts` from ambiguous newline `key=value` text to a JSON
object of exact keys and values, with `{}` for empty state. Consumers must decode
this object; embedded newlines/equals/quotes remain data through JSON escaping.
Stored object format, state key, pin/unpin args and status results remain unchanged.
The final output bound applies to the full encoded object after escaping. Provider
allocation limits and in-flight callback cancellation remain host responsibility;
cancellation never promises rollback of an already-started Save. This is bounded
session scratchpad, not long-term semantic memory.


## R19 / D35 scraper — preserve Markdown cap causes

Public ScrapePage/tool extraction overflow now retains ErrMarkdownExceedsLimit
through CodeValidationFailed; IsMarkdownExceedsLimit and errors.Is work for default,
custom and unchecked oversized custom output. Original custom cause remains
inspectable; user-facing limit text uses the configured cap, not custom diagnostics.
HTML source and final wire limits do not acquire the Markdown sentinel. Cancellation
wins before cap mapping, even when only the returned cause contains an interrupt.

Scraper calls remain synchronous with context checks before/after invocation; default
layout filtering also checks before work. Finite source input and returned-output
checks do not bound converter intermediates or force CPU preemption. Custom scrapers
must cooperate with context and enforce maxBytes; hostile work requiring hard limits
belongs in a host sandbox. No abandoned converter goroutine is created. Source,
Markdown and JSON budgets remain independent; library mode returns plain Markdown
and applies source/extraction limits, without a tool JSON envelope/wire budget.


## R20 / D35 DOCX — bounded WordML whitespace

DOCX extraction maps WordML tab to TAB and br/cr to LF, counting each inserted byte
against ParsedBytes before append. Default/textWrapping/page/column breaks flatten
to LF; extraction does not reconstruct pages, columns or Word layout. Adjacent styled
runs still concatenate directly, existing paragraph separators remain LF. No silent
truncation or partial result on overflow.

WordML recognition now uses exact transitional
`http://schemas.openxmlformats.org/wordprocessingml/2006/main`, strict
`http://purl.oclc.org/ooxml/wordprocessingml/main`, or legacy empty namespace. XML
prefix spelling is irrelevant. Foreign namespace nodes, including URIs containing
wordprocessingml as a substring, are ignored. This remains a text-only subset, not
a complete OOXML validator/layout engine; no nested text nodes are accepted.

Source snapshot, ZIP/expanded XML, text node, extracted-text and final JSON bounds
remain in force. XML parsing is synchronous with cooperative token/context checks,
not hard CPU/intermediate-allocation preemption. Host sandbox/parser adapter owns
stronger guarantees for hostile content. Stored format/tool result shape unchanged.


## R21 / D26 — generator recovery and explicit async streaming

Generator finalize errors/cancellation share one best-effort rollback path for
installed outputs and the current moved backup. Primary and secondary cleanup/
restore failures remain inspectable with affected target/recovery backup paths.
Failed restore retains the recovery copy; staging failures dispose owned generated
temps. Backup disposal after a full successful install is post-commit cleanup:
a cleanup diagnostic does not imply that new outputs were rolled back.
FileRecoveryError retains failed action/target/backup and cause; CommitComplete=true
marks post-commit backup cleanup, with complete Result.Files returned alongside error. The host
must provide exclusive access to target paths; no crash-atomic multi-file transaction
or hard interruption of filesystem syscalls is promised.

Generated stream:true factories return ordinary synchronous stream tools. Caller
Execute receives progress, final result and errors; invalid input is rejected before
handler invocation. Background execution is explicit host composition:
AsAsyncTool(base, WithBackgroundTimeout(...), WithMaxCollectedChunks(...),
WithOnComplete(...)). Accepted acknowledges scheduling, never terminal completion;
background errors/validation are reported through the configured completion hook,
not the already-returned caller. Parent cancellation is detached by the existing
async wrapper; host background timeout and Registry.Shutdown define that lifecycle.

## D01 — generic conversation compaction belongs to the host/contexty

Removed `github.com/skosovsky/toolsy/history`, its
`ApplySemanticTruncation`, generic counter/summarizer/inspector contracts, options
and `SemanticTruncationReport`; removed `toolsyotel.RecordSemanticTruncation` and
`examples/semantic_truncation`. Hosts own chat-history policy and its telemetry.
`historycodec`, tool-result transcripts, `ResultCodec` and typed BYOT execution
remain available. No mandatory dependency on contexty is introduced.

Contexty capability/semantic mapping and a compiled host recipe are documented
in `docs/history-compaction-migration.md` with verified source mapping. This is a
clear break, not an API alias or automatic message conversion.

## D02 — neutral bounded controls and host-owned UI routing

Removed `UIActionSignal` and `ErrUIAction`. Hosts use `HostEventSignal{Name,
PayloadJSON}` / `ErrHostEvent` for named data, and own an explicit allowlisted UI
adapter; neither event delivery nor payload grants authority. `JSONResultCodec`
writes kind `host_event` and rejects old `ui` records. Migrate persisted records
explicitly under host policy instead of silently replaying an old action.

Pause/Yield/Halt ask the host to pause/end/stop its continuation after this call.
They do not stop agent tracks, cancel contexts/other calls or persist continuation.
Manifest CompletionPolicy is host routing metadata; terminal result Controls are
collected declarations. Invalid controls fail INTERNAL post-handler, without
argument correction/retry. New inclusive limits: 64KiB field bytes per signal and
aggregate result list, 64 result controls, 128byte ASCII host event name; strict
UTF-8/JSON, typed-nil rejection. This is a clear API and cache-record break.

See [exact contract](control-contract.md) for field/name/delivery/cancellation
limits and [host example](../examples/host_event/main.go). Existing human toolkit
16KiB default payload cap fits the core bound; larger host overrides must also fit.

## D03 — human review is an intent

Human toolkit default `request_approval` is now `request_human_review`;
payload kind `approval` is now `human_review`. Action/reason field names remain
conversation data; `ask_human_clarification` and its payload remain unchanged.
Replace `WithApprovalName` / `WithApprovalDescription` with `WithReviewName` /
`WithReviewDescription`. Removed APIs have no compatibility aliases. Hosts must
update catalog names and payload routing explicitly; old transcripts describe the
old contract and must not be silently promoted to authority.

A review pause/reply has no authenticated approver, exact operation binding,
policy fingerprint, issuer, expiry or consume-once authority. Grant issuance
belongs to the authenticated host using the actual action's OperationProfile
challenge; resume the original operation through current policy. Conversation
text must not stand in for challenge DisplayJSON/Binding or permit dispatch.
The adapter owns no operation store, issuer or action execution port.

Payload configuration must fit core's inclusive 64KiB control budget; explicit
limits outside 1..MaxControlBytes fail construction. Default remains16KiB with
complete encodedJSON bounds and no text truncation. See [toolkit contract and
executable composition](../toolkits/human/README.md).

## D04 / D05 — primary policy and required gates

Registry authorization uses `WithPolicy(stableID, policy)` / `Decision`.
`WithAuthorizer`, `WithAuthorization` and `AuthorizationRequest` alias are removed;
use the narrow `NewAuthorizerPolicy(Authorizer)` adapter with PolicyRequest and a
stable policy ID. The adapter captures its provided authorizer; it does not resolve
an authorization dependency from RunEnv. Typed argument policy remains after
binding. Policy IDs must change with host authority semantics.

Explicit nil/typednil/nil function policy installation fails construction instead
of silently disabling a gate; no installed policy is an intentional optional mode.
`WithBudget` requires a valid BudgetTracker in DepKeyBudget at execution. Use
`WithOptionalBudget` only when missing budget enforcement is an explicit host
choice; supplied malformed/nil dependencies still fail. Budget storage/pricing and
physical-attempt accounting belong to host. Config failures cannot dispatch.

See [current gate contracts](policy-gates.md) for composition, snapshots, callback
lifecycle, cancellation and budget/replay accounting. No compatibility aliases
are retained. Independent acceptance evidence is recorded separately.


## D09 — required mutation and handler construction

Put, SetState and SetSessionState return error. Check or propagate that result.
Absent/zero RunEnv, unbound state Session, nil Session or empty key fail with
INTERNAL retaining ErrMutationConfiguration. A DI-only NewRunEnv(nil) supports Put
but cannot SetState. Nil values may be stored deliberately; Lookup/Get retain their
optional non-nil typed semantics. Host owns synchronization of referenced BYOT
values. All tool handler constructors reject nil functions with ErrToolHandlerNil;
policy wrapper rejects nil/typednil base tools. Nil handler rejection precedes
options/schema construction, including missing schema on proxy/dynamic constructors.

```go
if err := toolsy.Put(env, "db", db); err != nil { return err }
if err := toolsy.SetState(env, "counter", count); err != nil { return err }
if err := toolsy.SetSessionState(session, "counter", count); err != nil { return err }
```

There is no permissive mutation alias. For intentional absence, the host explicitly
branches before calling a required mutation. An empty key is invalid; nonempty keys
are opaque and are not trimmed. Put needs the initialized store from NewRunEnv;
SetState needs a bound session, while SetSessionState directly targets that session.
Storage accepts nil values; optional reads continue treating nil/typednil as absent.
The synchronized map is shared by cloned execution environments and the bound
session; arbitrary referenced values are not deep-copied or synchronized.
Session.Execute with Env:nil remains unbound and a propagated state mutation error
is observable instead of silently losing state. Existing caller code must handle
the newly returned errors, including dependency wiring before a budget gate.

See the [executable DI-only mutation example](../mutation_example_test.go) and
[snapshot example](../examples/session_snapshot/main.go). Nil function handlers fail
NewTool/NewStreamTool/NewProxyTool/NewDynamicToolFromSpec/NewTypedTool and
NewPolicyToolFromSpec before a callable tool is returned. NewPolicyTool validates
its base port; this does not certify arbitrary caller-owned tools' internals.


## D10 / D11 — named operation configuration and recovery

NewOperationProfile takes one OperationProfileConfig with named Store, Prepare,
Codec, Issuer, Clock, Lease and MaxBytes fields; the positional signature is removed. Required nil/typednil
ports, nil callbacks, empty issuer, nonpositive lease and negative caps fail with
ErrOperationProfileConfiguration. MaxBytes zero retains the bounded default for
both display JSON and encoded result. Host ports are captured, not owned/closed.

Retain original-grant recovery: a consumed grant is not replaced by any fresh
approval. An expired original approval cannot authorize a redispatch of its old
logical operation. Reconciliation is trusted/fenced evidence, not fresh approval.
Document audited new intent after uncertainty is resolved, current authority and
fresh bound approval, original provenance and downstream duplicate-effect safety.
See the [current operation contract](execution-contract.md#approval-and-operation-journal-contract)
for the exact original-grant restrictions and audited host reauthorization steps.
The store/claim/fence/reconciliation execution boundary is retained unchanged;
no implicit retry, grant replacement or mandatory harness dependency is added.

```go
profile, err := toolsy.NewOperationProfile(toolsy.OperationProfileConfig{
    Store: store, Prepare: prepare, Codec: codec, Issuer: "authenticated-host",
    Clock: time.Now, Lease: time.Minute, MaxBytes: 0,
})
if err != nil { return err }
```

MaxBytes applies to both display and encoded terminal result, defaults to 1 MiB,
and is inclusive when positive. Issuer is opaque/nonempty; construction does not
normalize or authenticate it. Config is captured by value, while referenced ports
and callback captures remain host-owned/concurrent-safe. Construction invokes no
host callback. The [approval journal example](../examples/approval_journal/main.go)
uses named fields and demonstrates challenge, bound issuance and durable replay.

## D14 — local journal maintenance and restore consistency

`RestoreOperationStore` now rejects incomplete reverse record/grant/reservation
links, including grant-bearing records without a consumed reservation and
approval expiry on a grantless record. Correct snapshots require no format change.
A malformed historical image must be reconciled from authenticated host evidence;
do not invent a reservation, clear the journal, or reissue an old operation merely
to make restore succeed. Validation checks structure, not authenticity or external
outcome truth. Expired original grants remain historical data.

The filejournal adapter retains full-image transactions with an inclusive 8MiB
zero-config default, no automatic eviction or retention API. See its
[maintenance and complexity contract](../adapters/execution/filejournal/README.md).
Hosts must preserve uncertainty, consumed approvals, fences and replay identities
when backing up or migrating after quiescing all workers. Storage growth is a host
capacity concern; bounded reference storage is not a distributed journal.

Unapproved claims must have an empty `GrantID`; inconsistent claims now fail with
`invalid_claim` before dispatch/mutation. Clear irrelevant grant IDs in host inputs.
Recovery cannot change the original approval mode for the same operation binding;
a downgrade/upgrade fails with `binding_mismatch`, preserving the old reservation.

## D23 — bounded gRPC reflection before tool publication

The gRPC adapter applies `Options.Services` before requesting any descriptors.
A broken excluded service no longer prevents discovery of selected services;
selected dependencies remain included. Duplicate service names fetch once.

New finite inclusive aggregate caps are `MaxDiscoveryServices` (default256 list
entries, including exclusions), `MaxDescriptorFiles` (default512 received blobs,
including repeated files/dependencies), and `MaxDiscoveryBytes` (default8MiB sum
of protobuf response sizes, including list/envelopes). Zero selects defaults;
negative limits, including `MaxResponseBytes`, now reject before reflection RPC.
Raise positive finite caps explicitly for a legitimately larger contract.
Conflicting same-name files fail discovery; no partial tool set is published.

The receive cap bounds each message before adapter processing; aggregate size
uses `proto.Size`, with additional decoded-memory cost and host deadline/connection
ownership. See the [gRPC discovery contract](../contracts/grpc/README.md) for quota,
error and per-message limitations. No discovery scheduler or core dependency added.

## D24 — custom remote task cancellation diagnostics

The `agents` module uses pinned Agent Protocol task envelopes and the distinct
**toolsy step-stream v1 extension** for SSE observation and POST cancellation.
Public comments now describe the remote adapter rather than implying a normative
Agent Protocol lifecycle or a remote workflow scheduler.

Optional `WithCancellationObserver` supplies host-only `CancellationDiagnostic`:
task reference, parent interrupt/custom cause, credentials/request stage, HTTP
acknowledgement and cleanup failure cause. Nil/absence disables the observer.
Callbacks run synchronously under the same five-second detached cleanup context;
host code must cooperate, handle concurrent calls and sanitize observations.
Diagnostics do not replace the original execution cause or become model output.
Core may wrap callback errors in `ErrStreamAborted`; their original causes remain
inspectable through `errors.Is`/`errors.As`.

Only an interrupted parent after acknowledged creation triggers this best-effort
cleanup. A stream-policy timeout or callback stop with an active parent stops reads
without implicitly cancelling the remote action. Direct `CancelTask` returns errors
directly and does not invoke this observer. HTTP acknowledgement remains distinct
from stopped remote execution; unknown outcomes still require host reconciliation.
See the [remote adapter interruption contract](../agents/README.md).

## D25 — vendor-neutral telemetry and explicit Langfuse mapping

`ext/toolsyotel.WithTracing` no longer emits `langfuse.*` attributes by default.
Add `WithLangfuseCompatibility(true)` for the vendor type/input/output mapping;
this flag does **not** enable content capture. Arguments, delivered chunks, errors,
panics and exception messages remain capture-off unless separately opted in with
`WithContentCapture(true)`. No new SDK/exporter dependency is required.

Update queries from `gen_ai.tool.call_id` to `gen_ai.tool.call.id`. Framework flags
`gen_ai.tool.soft_error`, `gen_ai.tool.soft_error_text`, `gen_ai.tool.control_signal`
and `gen_ai.tool.stream_aborted` now use `toolsy.tool.*` with the same suffix.
Captured successful/soft output uses `toolsy.tool.output`; Execute errors use
`toolsy.tool.error`. `gen_ai.tool.call.result` exists only after Execute returns nil
without a soft error. On panic no output/result is finalized. Original returned
errors and panic values are preserved.

**Chunk redaction cannot match a secret split across chunks.** Concatenation can
reconstruct it even when each fragment passed a whole-secret matcher. Hosts must
disable capture, omit entire sensitive chunks, or sanitize complete content under
a separate bounded host contract. Capture limits (default 4096 bytes per field,
including markers, valid UTF-8; invalid byte sequences become U+FFFD before the
cap) bound exported display strings, not raw chunk
preparation/redactor cost and not secret exposure. Portable and opted-in vendor
fields mirror the same redacted/capped values. See the
[adapter contract and examples](../ext/toolsyotel/README.md); exporter conformance
and host authentication/classification remain external responsibilities.

## D27 — E2B executable/argv seam and one output source

E2B `Runtime.Command` is now a literal executable, with `Runtime.Args []string`.
Convert `Command: "python /workspace/main.py"` to `Command: "python"` plus
`Args: []string{"/workspace/main.py"}`. Go's command becomes `"go"` and
`Args: []string{"run", "/workspace/main.go"}`. Do not pre-quote or escape args.
The exact `/workspace/<ScriptName>` argument must occur once; New canonicalizes
that one argument and the uploaded script path. A second already-canonical
reference is rejected too. Other literal args are unchanged.
Constructor rejects invalid UTF8/NUL, missing/duplicate script arg, empty executable
and invalid script path. Args are copied for option/config/per-dispatch ownership.

Implement `Session.StartAndWait(ctx, command, args, env, stdout, stderr)` with the
new `args []string` parameter. Preserve argv semantics; if a backend only accepts
one string, implement the single correct transport serialization boundary there.
The adapter no longer parses/encodes shell strings. Literal argv is not a sandbox,
program allowlist or prevention of programs interpreting their own flags; host
runtime policy remains trusted. Shell-like text in other arguments is not rewritten.

`CommandResult.Stdout` and `Stderr` are removed; only `ExitCode` remains. All output
must flow through supplied capped writers, propagating writer errors. No uncapped
buffered-output fallback exists. Inclusive per-stream256KiB, cancellation/timeout,
nonzero exit and detached5s cleanup contracts remain. The thin client must cooperate
with contexts; unit and executable local seams do not prove cloud destruction or
filesystem/network/CPU isolation. See [E2B contract/example](../adapters/sandbox/e2b/README.md).

## D30/D36 — thin RAG boundary and one final wire check

`toolkits/rag.Aggregate`, `Dedup`, `DedupBy`, and `Fallback` are removed. Pass one
host-owned `DocumentRetriever` to `AsSearchTool`; it is called at most once, with no hidden
routing/retry/fallback. Nil/typed-nil required retrievers fail construction.
Move those policies into your host/ragy/routery adapter.
The [runnable host recipe](../toolkits/rag/examples/host/main.go) validates required
providers/policy, uses explicit unavailable-index or empty-success fallback, keeps
cancellation/deadline terminal, joins primary/secondary causes on failure and
merges/deduplicates by a host-selected public source/chunk identity. No ragy/routery
SDK integration or external availability guarantee is claimed.

`capDocumentsForWire`, `wireByteSize` and `cloneDocuments` are removed. Provider
item/source bounds still count actual escaped JSON; filtered count still rejects
oversized collections without manufacturing continuation. A single formatter/
default-envelope → host-validator → JSON wire check now enforces the final cap.
`WithMaxBytes` counts that complete wire JSON, including envelope and escaping,
with inclusive limits. `format.WireLimitError` remains inspectable through the
returned validation error. JSON and documents are never sliced/dropped. Host
validators run before the final wire cap; do not depend on the former precheck
preventing validator invocation on oversized default envelopes.

Retriever/filter/formatter/validator containers and metadata are borrowed host
values: keep them stable/read-only or arrange your own ownership/synchronization.
The removed shallow clone was not a deep-copy guarantee. Once the RAG handler is
entered, cancellation and custom parent causes survive its callback boundaries.
An already-cancelled/expired call may instead be rejected by the existing core
predispatch check before this handler: the standard interrupt is retained, but
custom cause is not promised there, and no retriever runs. Uncooperative callbacks
cannot be preempted. Provider/internal callback resource costs remain outside accepted-input
and exported-wire bounds. Read the [RAG contract](../toolkits/rag/README.md).


## D32 — toolkit constructor validation and ownership

All eleven toolkit modules reject nil `Option` arguments with errors. This includes
`AsToolsWithCleanup`/`AsToolWithCleanup` and web `SearchStructured`/`ScrapePage`.
Negative limits now reject construction rather than silently selecting defaults.
Zero still selects finite defaults where previously documented; human retains its
explicit zero-payload-limit rejection. Options apply in order, with final values
validated; later valid values can replace earlier negative values.

`memory.NewScratchpad(opts...)` now returns `(*Scratchpad, error)`. Handle that error
before calling `AsTools`; negative limits no longer produce an invalid instance.
`AsTools` continues to reject positive budgets too small for mandatory status JSON.

HTTP host allowlists, credential origins and metadata headers, web blocked-domain
lists, and SQL inspected-table lists snapshot inputs at option creation and copy
again for each application. Mutating original containers after `With...` returns or
reusing one option cannot change existing policy. Concurrent mutation during the
snapshot itself is unsupported. SQL inspected-table filters confer no SQL authority.

Host providers, databases, roots, stores, custom scrapers, callback functions and
captured state remain borrowed. Hosts own lifetime, context cooperation and safe
concurrent use; there is no deep-cloning or synchronization promise for arbitrary
host state. Keep returned data stable while toolkit callbacks and encoding consume
it. TLS pool configuration is cloned with the existing R07 limitation: referenced
certificates/root/callback state remains immutable for the configuration lifetime.


## D34 — name the SQL lexical filter honestly

Internal `sqlutil.ValidateReadOnlyQuery` is replaced by
`sqlutil.ValidateSelectLexicalSubset`; all toolkit callers/tests use the new name,
with no compatibility alias. SQL tool names remain stable. Validation messages
now describe rejected tokens/semicolons rather than a read-only guarantee.

The acceptance algorithm remains the same: first scanned token SELECT/WITH;
selected forbidden statement tokens and every unquoted/uncommented semicolon
reject. It is not a full parser, syntax validator, permission check or absence-of-
side-effects proof. Doubled quote escapes, -- comments and first-closing block
comments are the lexical subset; nested blocks, dollar/backtick/bracket quoting,
backslash/#/executable-comment dialect forms are not interpreted correctly.
Malformed/unrecognized syntax may reach the database and accepted SELECT functions
or SELECT INTO can have effects. Supported dialect names select schema inspection
queries, not SQL grammar validation.

Host database role/connection privileges and callable routine/extension authority
remain the enforcement boundary. SQLite query_only/mode=ro blocks database writes,
but not effects in host SQL functions. `WithAllowedTables` remains inspection-only,
and read-only tool metadata describes the host's configured connection intention.
The runnable local `toolkits/sqltool/examples/host` verifies its actual SQLite
read-only connection and finite budget integration, with no postgres/mysql claim.


## D36 — time locations, calendar arithmetic and StateStore

`WithLocation` applies to both `time_current` local display and `time_calculate`
calendar arithmetic/output. A non-nil `WithLocationProvider` overrides the static
location on every call of either tool; provider nil/error results fail without
fallback. A nil provider disables the dynamic override. An RFC3339 base's offset
specifies its instant; the toolkit converts that instant into the host location,
adds calendar days with AddDate, then exact elapsed hours with Add, preserving
fractional seconds. Zero deltas still express the instant in the host zone.

One calendar day can be 23/25 hours across ordinary DST changes, while 24 elapsed
hours can shift wall time. Ambiguous/nonexistent local times follow Go normalization
with no promised choice of offset; actual rules come from timezone data. Arithmetic
is retained, not a newly fixed defect. Precise public DST/negative/order fixtures
replace misleading/vacuous historical examples. Runnable timetool/examples/host
explicitly resolves a host timezone key through a bounded StateStore callback.

Current persisted storage is `RunEnv.StateStore` via `WithStateStore`: borrowed host
Load/Save, separate from Get/SetSessionState's in-memory map and excluded from
SessionSnapshot. Active legacy run.State references were already removed by earlier
rows; memory remains explicitly backed by StateStore. No automatic timezone key,
state framework, durable local fixture guarantee or hard callback cancellation is
introduced. Host provider lifetime, concurrent access and upstream bounds remain
host responsibilities.
